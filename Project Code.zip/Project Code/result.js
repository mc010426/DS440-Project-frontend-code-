document.addEventListener('DOMContentLoaded', () => {
    // Retrieve the score from the URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const score = parseFloat(urlParams.get('score')); // Make sure the score is a floating point number

    // Update the score on the page
    const scoreElement = document.getElementById('score');
    scoreElement.textContent = score.toFixed(2);

    // Determine the prediction and update the page accordingly
    const predictionElement = document.getElementById('prediction');
    const finalResultElement = document.getElementById('final-result-value');
    const finalResultContainer = document.getElementById('final-result');

    if (score < 0.6) {
        predictionElement.textContent = 'Uncertain';
        finalResultElement.textContent = 'Fake or Uncertain';
        finalResultContainer.style.color = '#e53e3e'; // Red color for uncertain/fake
    } else {
        predictionElement.textContent = 'Real';
        finalResultElement.textContent = 'Real';
        finalResultContainer.style.color = '#48bb78'; // Green color for real
    }
});